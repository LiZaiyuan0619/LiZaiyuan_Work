int main(){
    int a = 10,b = 5;
	int c = 2;
    if(a > b){
		c = a + 2 * b;
	}else{
		c = b;
	}
	while(a > 0){
		a = 10;
	}
    return a;
}