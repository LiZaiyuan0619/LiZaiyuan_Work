
#ifndef GENLLVM_H
#define GENLLVM_H

#include "ast.h"

enum {T_INT = 1};
#define true 1
#define false 0

int genExpr(past node);


#endif
