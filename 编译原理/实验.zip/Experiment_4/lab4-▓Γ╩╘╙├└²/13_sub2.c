//test sub
const int a = 10;
int main(){
    int b;
    b = 2;
    return b - a;
}