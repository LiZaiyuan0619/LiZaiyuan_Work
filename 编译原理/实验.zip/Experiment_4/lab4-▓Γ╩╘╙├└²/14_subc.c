//test subc
int main(){
    int a;
    a = 10;
    return a - 2;
}