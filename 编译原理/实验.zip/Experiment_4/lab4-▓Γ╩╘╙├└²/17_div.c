//test div
int main(){
    int a, b;
    a = 10;
    b = 5;
    return a / b;
}