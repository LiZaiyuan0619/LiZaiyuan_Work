//test mulc
const int a = 5;
int main(){
    return a * 5;
}