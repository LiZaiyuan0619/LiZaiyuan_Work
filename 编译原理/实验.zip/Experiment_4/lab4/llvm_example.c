void func()
{
	int A = 1, B = 2, C = 3, D = 4;
	A = -B*(C+D);	
}
