1.主框架

```js
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>第一个three.js文件_WebGL三维场景</title>
  <script src="./three.js"></script>
</head>

<body>
	<script>
        var scene = new THREE.Scene();
        var width = window.innerWidth; //窗口宽度
        var height = window.innerHeight; //窗口高度
        var k = width / height; //窗口宽高比
        var s = 200; //三维场景显示范围控制系数，系数越大，显示的范围越大
        var camera = new THREE.OrthographicCamera(-s * k, s * k, s, -s, 1, 1000);
        camera.position.set(200, 300, 200); //设置相机位置
        camera.lookAt(scene.position)
        //渲染器对象
        var renderer = new THREE.WebGLRenderer();
        renderer.setSize(width, height);
        renderer.setClearColor(0xb9d3ff, 1);
        document.body.appendChild(renderer.domElement); //**
        function render() {
                renderer.render(scene,camera);//执行渲染操作
                requestAnimationFrame(render);//请求再次执行渲染函数render
            }
        render();
	</script>
</body>
</html>
```

2.场景绘制

```js
    var geometry = new THREE.BoxGeometry(100, 100, 100); 
    var material = new THREE.MeshLambertMaterial({
      color: 0x0000ff
    }); 
    var mesh = new THREE.Mesh(geometry, material);
    scene.add(mesh); 

    var point = new THREE.PointLight(0xffffff);
    point.position.set(400, 200, 300); 
    scene.add(point); 

    var ambient = new THREE.AmbientLight(0x444444);
    scene.add(ambient);
```

3.利用threejs实现对象的运动控制的设计，如太阳系运动，以及汽车与轮子运动等。

```js
    var geometry = new THREE.BoxGeometry(100, 100, 100); 
    var material = new THREE.MeshLambertMaterial({
      color: 0x0000ff
    }); 
    var mesh = new THREE.Mesh(geometry, material);
    scene.add(mesh);

function render() {
    	mesh.position.x = mesh.position.x + 1
        renderer.render(scene,camera);//执行渲染操作
        requestAnimationFrame(render);//请求再次执行渲染函数render
    }
render();
```

4.[天空盒](https://blog.csdn.net/qq_37994494/article/details/76573540)

```js
var path = "../examples/textures/cube/Park3Med/";//设置路径
var directions  = ["px", "nx", "py", "ny", "pz", "nz"];//获取对象
var format = ".jpg";//格式
//创建盒子，并设置盒子的大小为( 5000, 5000, 5000 )
var skyGeometry = new THREE.BoxGeometry( 5000, 5000, 5000 );
//设置盒子材质
var materialArray = [];
for (var i = 0; i < 6; i++)
    materialArray.push( new THREE.MeshBasicMaterial({
        map: THREE.ImageUtils.loadTexture( path + directions[i] + format ),//将图片纹理贴上
        side: THREE.BackSide/*镜像翻转，如果设置镜像翻转，那么只会看到黑漆漆的一片，因为你身处在盒子的内部，所以一定要设置镜像翻转。*/
    }));
var skyMaterial = new THREE.MeshFaceMaterial( materialArray );
var skyBox = new THREE.Mesh( skyGeometry, skyMaterial );//创建一个完整的天空盒，填入几何模型和材质的参数
scene.add( skyBox );//在场景中加入天空盒
```

5.利用threejs设计实现一个简单游戏：用鼠标控制旋转方向，键盘控制向前向后移动，空格键发射子弹，射线检测碰撞结果

```js
//救命!

//(一）鼠标控制旋转
    var rotateStart;
   	rotateStart = new THREE.Vector2();
    var pivot = new THREE.Object3D();//创建一个obj对象

    /*
        鼠标移动控制模型旋转思想：
        当按下鼠标时及时当前鼠标的水平坐标clientX1，在鼠标移动的过程中不断触发onMouseMove事件，
        不停的记录鼠标的当前坐标clientX2，由当前坐标减去记录的上一个水平坐标，
        并且将当前的坐标付给上一个坐标clientX1，计算两个坐标的之间的差clientX2-clientX1，
        将得到的差值除以一个常量（这个常量可以根据自己的需要调整），得到旋转的角度
    */
    function onMouseDown(event){
        event.preventDefault();
        mouseDown = true;
        mouseX = event.clientX;//出发事件时的鼠标指针的水平坐标

        rotateStart.set( event.clientX, event.clientY );
        document.addEventListener( 'mousemove', onMouseMove2, false );
    }

    function onMouseup(event){      
        mouseDown = false;

        document.removeEventListener("mousemove", onMouseMove2);
    }

    function onMouseMove2(event){
        if(!mouseDown){
            return;
        }       
        var deltaX = event.clientX - mouseX;
        mouseX = event.clientX;
        rotateScene(deltaX);        
    }

    //设置模型旋转速度，可以根据自己的需要调整
    function rotateScene(deltaX){
        //设置旋转方向和移动方向相反，所以加了个负号
        var deg = -deltaX/279;
        //deg 设置模型旋转的弧度
        pivot.rotation.y += deg;
        render();
    }

//键盘控制移动，使用jquery；同时实现空格键发射子弹
 $(window).keydown(function (event) {
        switch (event.keyCode) {
            case 65: // a
                left = true;
                break;
            case 68: // d
                right = true;
                break;
            case 83: // s
                back = true;
                break;
            case 87: // w
                front = true;
                break;
            case 32: //空格
            //发射子弹
                shutbin = true;
       
            break;
                
        }
    });

    $(window).keyup(function (event) {
        switch (event.keyCode) {
            case 65: // a
                left = false;
                break;
            case 68: // d
                right = false;
                break;
            case 83: // s
                back = false;
                break;
            case 87: // w
                front = false;
                break;
            case 32: //空格
            //发射子弹
                shutbin = false;
            break;
       
    }

        }
    });

 function animate() {			//实时渲染
        requestAnimationFrame(animate);
        renderer.render(scene, camera);

        if (front) {
            // cube.translateZ(-1)
            cube.position.z -= 1;
        }
        if (back) {
            // cube.translateZ(1);
            cube.position.z += 1;
        }
        if (left) {
            // cube.translateX(-1);
            cube.position.x -= 1;
        }
        if (right) {
            // cube.translateX(1);
            cube.position.x += 1;
        }
     	if(shutbin) {
               game();   //将zidan的模型体导入，同时导入cube模型是为了获取他的位置坐标
        }
    }
var v=100;
function game(){
    zidan.position = cube.position; //cube是我们的主物体，将物体的位置赋值给zidan
    zidan.rotation = cube.rotation;
    if(！check()){    
        zidan.position.X +=Math.cos(zidan.rotation)* v ;
    	zidan.position.Y +=Math.sin(zidan.rotation)* v ;
        }
    else{
        scene.remove(zidan);
    }
    
  // Raycaster来检测碰撞的原理很简单，我们需要以物体的中心为起点，向各个顶点（vertices）发出射线，然后检查射线是否与其它的物体相交。如果出现了相交的情况，检查最近的一个交点与射线起点间的距离，如果这个距离比射线起点至物体顶点间的距离要小，则说明发生了碰撞。 
    
check(){
 
    var originPoint = movingCube.position.clone();
 var crash =false;
for (var vertexIndex = 0; vertexIndex < movingCube.geometry.vertices.length; vertexIndex++) {
 // 顶点原始坐标
 var localVertex = movingCube.geometry.vertices[vertexIndex].clone();
 // 顶点经过变换后的坐标
 var globalVertex = localVertex.applyMatrix4(movingCube.matrix);
 // 获得由中心指向顶点的向量
 var directionVector = globalVertex.sub(movingCube.position);
 
 // 将方向向量初始化
 var ray = new THREE.Raycaster(originPoint, directionVector.clone().normalize());
 // 检测射线与多个物体的相交情况
 var collisionResults = ray.intersectObjects(collideMeshList);
 // 如果返回结果不为空，且交点与射线起点的距离小于物体中心至顶点的距离，则发生了碰撞
 if (collisionResults.length > 0 && collisionResults[0].distance < directionVector.length()) {
  crash = true; // crash 是一个标记变量
 }
    return crash;
}
}  
}
//空格键发射子弹
```

6.利用threejs设计实现一个函数曲线的绘制

```js
//样条曲线
var geometry = new THREE.Geometry();
var curve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0, 0, 90),
    new THREE.Vector3(-10, 40, 40),
    new THREE.Vector3(0, 0, 0),
    new THREE.Vector3(60, -60, 0),
    new THREE.Vector3(70, 0, 80)
]);
var points = curve.getPoints(100);
geometry.setFromPoints(points);
var material = new THREE.LineBasicMaterial({
    color: 0xff00f0
});
var line = new THREE.Line(geometry, material);
scene.add(line);
```

7.利用threejs设计实现一个曲面的绘制

```js
//Shape对象
var shape = new THREE.Shape(); //Shape对象
shape.arc(0, 0, 100, 0, 2 * Math.PI);
var geometry = new THREE.ShapeGeometry(shape, 50);
var material = new THREE.MeshBasicMaterial({
    color: 0xff0000,
});
var mesh = new THREE.Mesh(geometry, material);
mesh.position.z = 100;
scene.add(mesh);
```

---

---

---

## 利用threejs设计实现一个模型文件的加载和场景绘制

```js
        import * as THREE from 'three';
        import { OrbitControls } from 'js/OrbitControls';
        import { PCDLoader } from 'js/PCDLoader';

        // 创建场景
        const scene = new THREE.Scene();

        // 创建摄像机
        const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        camera.position.z = 5;

        // 创建渲染器
        const renderer = new THREE.WebGLRenderer();
        renderer.setSize(window.innerWidth, window.innerHeight);
        document.body.appendChild(renderer.domElement);

        // 添加光源
        const light = new THREE.AmbientLight(0x404040); // soft white light
        scene.add(light);

        // 加载模型
        const loader = new PCDLoader();
        loader.load('images/ism_test_cat.pcd', function (pcd) {
            scene.add(pcd);
        }, undefined, function (error) {
            console.error(error);
        });

        // 添加控制器
        const controls = new OrbitControls(camera, renderer.domElement);

        // 渲染循环
        function animate() {
            requestAnimationFrame(animate);
            controls.update();
            renderer.render(scene, camera);
        }
        animate();

```

## 利用threejs实现三维文字信息tip注释的功能。

```js
import * as THREE from 'three';

// 基本的 Three.js 设置（场景、摄像机、渲染器）
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer();
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

// 创建一个物体（例如，立方体）
const geometry = new THREE.BoxGeometry();
const material = new THREE.MeshBasicMaterial({ color: 0x00ff00 });
const cube = new THREE.Mesh(geometry, material);
scene.add(cube);

// 将摄像机向后移动，以便能看到物体
camera.position.z = 5;

// 获取提示框元素
const tooltip = document.getElementById('tooltip');

// 渲染循环
function animate() {
    requestAnimationFrame(animate);

    // 更新物体位置
    cube.rotation.x += 0.01;
    cube.rotation.y += 0.01;

    // 更新提示框位置
    updateTooltip(cube);

    renderer.render(scene, camera);
}
animate();

// 更新提示框位置的函数
function updateTooltip(object) {
    const vector = new THREE.Vector3();
    object.getWorldPosition(vector);
    vector.project(camera);

    vector.x = (vector.x + 1) / 2 * window.innerWidth;
    vector.y = -(vector.y - 1) / 2 * window.innerHeight;

    tooltip.style.top = `${vector.y}px`;
    tooltip.style.left = `${vector.x}px`;
}

// 显示提示框并更新内容
function showTooltip(content) {
    tooltip.style.display = 'block';
    tooltip.innerHTML = content;
}

// 示例：当鼠标悬停在立方体上时显示提示
document.addEventListener('mousemove', (event) => {
    // 这里需要添加更复杂的逻辑来检测鼠标是否悬停在立方体上
    // 例如，使用 raycaster
    showTooltip('This is a cube');
});

// 示例：当鼠标移出立方体时隐藏提示
document.addEventListener('mouseout', (event) => {
    tooltip.style.display = 'none';
});

```

## 利用threejs的raycaster.setFromCamera( pointer, camera )实现鼠标选中三维物体进行交互

```js
import * as THREE from 'three';

// 基本设置
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer();
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

// 添加物体
const geometry = new THREE.BoxGeometry();
const material = new THREE.MeshBasicMaterial({ color: 0x00ff00 });
const cube = new THREE.Mesh(geometry, material);
scene.add(cube);

// 将摄像机向后移动，以便能看到物体
camera.position.z = 5;

// Raycaster 和鼠标向量
const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();

// 鼠标移动事件
function onMouseMove(event) {
    // 将鼠标位置转换为标准化设备坐标（NDC）
    mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
    mouse.y = - (event.clientY / window.innerHeight) * 2 + 1;

    // 更新射线
    raycaster.setFromCamera(mouse, camera);

    // 检测射线与物体的相交
    const intersects = raycaster.intersectObjects(scene.children);

    for (let i = 0; i < intersects.length; i++) {
        // 交互逻辑，例如更改物体颜色
        intersects[i].object.material.color.set(0xff0000);
    }
}

window.addEventListener('mousemove', onMouseMove);

// 渲染循环
function animate() {
    requestAnimationFrame(animate);
    renderer.render(scene, camera);
}
animate();

```

